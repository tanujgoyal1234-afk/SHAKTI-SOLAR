SHAKTI SOLAR PROFESSIONAL WEBSITE
===================================

Upload/replace index.html in the GitHub repository used by GitHub Pages.

This version:
- Enlarges the Shakti Solar logo
- Improves heading and section spacing
- Improves mobile responsiveness
- Adds a floating WhatsApp button
- Keeps the Sri Ganganagar branch content and product/brand sections
