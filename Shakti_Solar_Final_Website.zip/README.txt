SHAKTI SOLAR - FINAL WEBSITE
=============================

Open index.html in a browser to preview the website.

Included:
- Shakti Solar logo
- Sri Ganganagar Branch
- Address: C-14 SHAKTI SOLAR, New Loha Mandi, Sri Ganganagar, Near Maharaja Hotel
- Solar panel brands: Waaree, Adani Solar, Tata Power Solar, Microtek
- Solar inverter brands: VSOLE, Polycab, Microtek
- Rooftop Solar, PM Surya Ghar and Solar Loan services
- Contact and WhatsApp buttons

Contact numbers currently shown on the page:
9253117193
6376023424
